<head><title>Welcome</title></head>

Room Manager
=============

Welcome to the Room Manager project.

`TODO Project description.`

Project Documentation
---------------------

This section provides technical information and reports.

* todo


